# scripts to help auth jira cli to self-hosted jira.
